import {prepareIndex, searchIndex, normalize} from './search-engine.js';

const form = document.getElementById('site-search-form');
const query = document.getElementById('site-query');
const category = document.getElementById('site-category');
const results = document.getElementById('site-search-results');
const status = document.getElementById('site-search-status');
const empty = document.getElementById('site-search-empty');
const more = document.getElementById('site-search-more');
const retry = document.getElementById('site-search-retry');
const labels = {business:'Business & Technology',products:'Products & services',projects:'Projects',company:'Company & careers',news:'News'};
let index = null, matches = [], limit = 12, timer;

function restore() {
  const params = new URLSearchParams(location.search);
  query.value = (params.get('q') || '').slice(0, 200);
  const selected = params.get('category') || '';
  category.value = [...category.options].some(option => option.value === selected) ? selected : '';
  syncLanguageLinks();
}
function syncLanguageLinks() {
  for (const link of document.querySelectorAll('a[hreflang]')) {
    const destination = new URL(link.href);
    if (destination.origin !== location.origin) continue;
    for (const [name, value] of [['q', query.value.trim()], ['category', category.value]]) {
      if (value) destination.searchParams.set(name, value);
      else destination.searchParams.delete(name);
    }
    link.href = destination.href;
  }
}
function persist(push = false) {
  syncLanguageLinks();
  const url = new URL(location.href);
  for (const [key,value] of [['q',query.value.trim()],['category',category.value]]) {
    if (value) url.searchParams.set(key,value); else url.searchParams.delete(key);
  }
  const destination = url.pathname + url.search;
  if (destination !== location.pathname + location.search) history[push ? 'pushState' : 'replaceState'](null,'',destination);
}
function snippet(row) {
  const terms = normalize(query.value).split(' ').filter(Boolean);
  if (!terms.length || terms.some(term => normalize([row.title,row.aliases,row.description].join(' ')).includes(term))) return row.description;
  const folded = normalize(row.body);
  const positions = terms.map(term => folded.indexOf(term)).filter(position => position >= 0);
  if (!positions.length) return row.description;
  const start = Math.max(0, Math.min(...positions)-35);
  return (start ? '…' : '') + row.body.slice(start, start+150) + (row.body.length > start+150 ? '…' : '');
}
function element(tag, text, className) {
  const node = document.createElement(tag);
  if (text) node.textContent=text;
  if (className) node.className=className;
  return node;
}
function render() {
  if (!index) return;
  const fragment = document.createDocumentFragment();
  for (const row of matches.slice(0,limit)) {
    const item=element('li', '', 'site-search-result');
    const meta=element('p',labels[row.category] + (row.prtimes ? ' · PR TIMES' : ''),'search-result-meta');
    if (row.date) {const time=element('time',row.date.slice(0,10));time.dateTime=row.date;meta.append(' · ',time);}
    const heading=element('h2'); const anchor=element('a',row.title);anchor.href=row.url;heading.append(anchor);
    item.append(meta,heading,element('p',snippet(row),'search-result-snippet'));fragment.append(item);
  }
  results.replaceChildren(fragment);
  empty.hidden=matches.length>0;
  more.hidden=matches.length<=limit;
  status.textContent=`${matches.length} results${matches.length ? ` (${Math.min(matches.length,limit)} shown)` : ''}`;
}
function filter() {
  if (!index) return;
  limit=12;matches=searchIndex(index,query.value,category.value);render();
}
async function load() {
  status.textContent='Preparing search…';retry.hidden=true;empty.hidden=true;
  try {
    const response=await fetch('/muroosystems-pages/assets/site-search-en.json');
    if (!response.ok) throw new Error('Index unavailable');
    const rows=await response.json();
    if (!Array.isArray(rows)) throw new Error('Invalid index');
    index=prepareIndex(rows);filter();
  } catch {
    status.textContent='Search could not be loaded. Reload or browse the page list below.';retry.hidden=false;
  }
}
form.addEventListener('submit',event=>{event.preventDefault();clearTimeout(timer);persist(true);filter();});
query.addEventListener('input',()=>{syncLanguageLinks();clearTimeout(timer);timer=setTimeout(()=>{persist();filter();},160);});
category.addEventListener('change',()=>{clearTimeout(timer);persist(true);filter();});
document.getElementById('site-reset').addEventListener('click',()=>{clearTimeout(timer);query.value='';category.value='';persist(true);filter();query.focus();});
document.querySelectorAll('[data-query]').forEach(button=>button.addEventListener('click',()=>{clearTimeout(timer);query.value=button.dataset.query;category.value='';persist(true);filter();query.focus();}));
more.addEventListener('click',()=>{const prior=limit;limit+=12;render();results.children[prior]?.querySelector('a')?.focus();});
retry.addEventListener('click',load);
window.addEventListener('popstate',()=>{clearTimeout(timer);restore();filter();});
restore();load();
